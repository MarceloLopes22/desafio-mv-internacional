package com.desafio.mv.internacional.produto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioMvApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioMvApplication.class, args);
	}

}
